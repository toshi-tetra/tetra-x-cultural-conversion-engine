# Tetra-X Cultural Conversion Engine

AI-powered tool that takes a product page URL and generates culturally adapted brand taglines for US English and Japanese markets.

## Architecture

- **Frontend**: React + Vite + Tailwind v4 + shadcn/ui + Framer Motion
- **Backend**: Express (Node/TypeScript)
- **AI**: OpenAI via Replit AI Integrations (gpt-4o)
- **No database** — stateless tool, no persistence needed

## How It Works

1. User enters a product page URL
2. Backend fetches the page HTML and extracts text (headings, paragraphs)
3. Extracted text is sent to OpenAI with a structured prompt
4. AI returns: brand narrative, consumer truths, US taglines, Japanese taglines, cultural explanation
5. Frontend displays results with fixed cultural lens indicator bars

## Key Files

- `client/src/pages/Home.tsx` — Main UI (single page app)
- `server/routes.ts` — API route `/api/analyze` that handles URL fetching + AI generation
- `client/src/index.css` — Design system (Tailwind v4 CSS variables)

## Fonts

- **Outfit** — UI body text (sans-serif)
- **Playfair Display** — Headlines and taglines (serif)
- **Space Mono** — Labels and indicators (monospace)

## Cultural Lens Indicators (Fixed Presets)

| Indicator | US | Japan |
|---|---|---|
| Directness | 5 | 2 |
| Emotion | 3 | 4 |
| Figurative | 2 | 5 |
| Narrative | 2 | 4 |
