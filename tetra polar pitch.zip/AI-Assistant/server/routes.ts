import type { Express } from "express";
import { createServer, type Server } from "http";
import OpenAI from "openai";
import { z } from "zod";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const analyzeSchema = z.object({
  url: z.string().url("Please provide a valid URL"),
});

async function fetchPageText(url: string): Promise<string> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; Tetra-X/1.0; +https://tetra-x.replit.app)",
        Accept: "text/html,application/xhtml+xml",
      },
    });

    if (!res.ok) {
      throw new Error(`Failed to fetch page: HTTP ${res.status}`);
    }

    const html = await res.text();

    const tagPattern = /<(h1|h2|h3|h4|p|li|span|title|meta[^>]*content)[^>]*>([\s\S]*?)<\/\1>/gi;
    const matches: string[] = [];
    let match;
    while ((match = tagPattern.exec(html)) !== null) {
      const text = match[2]
        .replace(/<[^>]+>/g, "")
        .replace(/&[a-z]+;/gi, " ")
        .replace(/\s+/g, " ")
        .trim();
      if (text.length > 5) {
        matches.push(text);
      }
    }

    const combined = matches.join("\n").slice(0, 6000);
    if (combined.length < 50) {
      throw new Error(
        "Could not extract enough text content from this page. The page may be JavaScript-rendered or have limited text."
      );
    }
    return combined;
  } finally {
    clearTimeout(timeout);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/analyze", async (req, res) => {
    try {
      const parsed = analyzeSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: parsed.error.issues[0]?.message || "Invalid input",
        });
      }

      const { url } = parsed.data;

      let pageText: string;
      try {
        pageText = await fetchPageText(url);
      } catch (err: any) {
        return res.status(422).json({
          error: err.message || "Failed to fetch the page content.",
        });
      }

      const systemPrompt = `You are Tetra-X, a cultural conversion engine for brand messaging. You analyze product page content and generate culturally adapted taglines.

You will receive extracted text from a product page. Your job:
1. Identify the brand's narrative (what the brand claims about itself)
2. Extract 2-3 real review snippets or customer-voice quotes from the page text (verbatim or closely paraphrased short fragments)
3. Identify consumer truths (what customers seem to value, derived from reviews and product descriptions)
4. Generate US English taglines (direct, confident, concise, 3-6 words)
5. Generate Japanese taglines (subtle, emotional, figurative — NOT literal translations)
6. Explain why the US and Japanese taglines differ culturally

Respond ONLY with valid JSON in this exact format:
{
  "brandNarrative": "A 1-2 sentence summary of the brand messaging.",
  "reviewSnippets": ["short review quote 1", "short review quote 2", "short review quote 3"],
  "consumerTruths": ["truth 1", "truth 2", "truth 3"],
  "usTaglines": ["tagline 1", "tagline 2", "tagline 3"],
  "japanTaglines": ["日本語タグライン1", "日本語タグライン2", "日本語タグライン3"],
  "explanation": "A short explanation of why the US and Japanese taglines differ culturally."
}

Rules:
- reviewSnippets must have 2-3 items, each a short verbatim or closely paraphrased customer quote found in the page text (max 20 words each). If no reviews exist on the page, synthesize realistic customer-voice quotes based on product claims.
- consumerTruths must have exactly 3 items
- usTaglines must have exactly 3 items, each 3-6 words, in American English
- japanTaglines must have exactly 3 items, in Japanese, emotionally resonant and figurative
- explanation must be in English`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: `Analyze the following product page content and generate culturally adapted taglines:\n\n${pageText}`,
          },
        ],
        temperature: 0.7,
        response_format: { type: "json_object" },
      });

      const content = completion.choices[0]?.message?.content;
      if (!content) {
        return res.status(500).json({ error: "No response from AI model." });
      }

      let result;
      try {
        result = JSON.parse(content);
      } catch {
        return res
          .status(500)
          .json({ error: "Failed to parse AI response." });
      }

      return res.json({
        brandNarrative: result.brandNarrative || "",
        reviewSnippets: result.reviewSnippets || [],
        consumerTruths: result.consumerTruths || [],
        usTaglines: result.usTaglines || [],
        japanTaglines: result.japanTaglines || [],
        explanation: result.explanation || "",
      });
    } catch (err: any) {
      console.error("Analysis error:", err);
      return res.status(500).json({
        error: "An unexpected error occurred during analysis. Please try again.",
      });
    }
  });

  return httpServer;
}
