import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, ArrowRight, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface AnalysisResult {
  brandNarrative: string;
  reviewSnippets: string[];
  consumerTruths: string[];
  usTaglines: string[];
  japanTaglines: string[];
  explanation: string;
}

interface DisplayResult {
  brandNarrative: string;
  reviewSnippets: string[];
  consumerTruths: string[];
  usTaglines: string[];
  japanTaglines: string[];
  explanation: string;
}

const US_BARS = [
  { label: "Directness", val: 5 },
  { label: "Emotion", val: 3 },
  { label: "Figurative", val: 2 },
  { label: "Narrative", val: 2 },
];

const JP_BARS = [
  { label: "Directness", val: 2 },
  { label: "Emotion", val: 4 },
  { label: "Figurative", val: 5 },
  { label: "Narrative", val: 4 },
];

const MiniBar = ({ val, max = 5 }: { val: number; max?: number }) => (
  <div className="flex gap-[3px]">
    {Array.from({ length: max }).map((_, i) => (
      <div
        key={i}
        className={`w-[14px] h-[4px] rounded-[1px] ${i < val ? "bg-foreground/40" : "bg-foreground/[0.06]"}`}
      />
    ))}
  </div>
);

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.45, ease: [0.25, 0.46, 0.45, 0.94] },
};

export default function Home() {
  const [url, setUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<DisplayResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setIsAnalyzing(true);
    setResults(null);
    setError(null);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong.");
        return;
      }
      const r = data as AnalysisResult;
      setResults({
        brandNarrative: r.brandNarrative,
        reviewSnippets: r.reviewSnippets || [],
        consumerTruths: r.consumerTruths,
        usTaglines: r.usTaglines,
        japanTaglines: r.japanTaglines,
        explanation: r.explanation,
      });
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-foreground/[0.06]  sticky top-0 z-50 bg-background/80 backdrop-blur-xl">
        <div className="max-w-[960px] mx-auto px-6 h-12 flex items-center justify-between">
          <span className="text-[13px] font-medium tracking-[-0.01em]">Tetra‑X</span>
          <span className="text-[10px] text-foreground/30 font-mono tracking-[0.1em] uppercase">Cultural Conversion Engine</span>
        </div>
      </header>

      <main className="max-w-[960px] mx-auto px-6">

        {/* Hero */}
        <section className="pt-20 pb-16 max-w-[520px]">
          <motion.h1
            {...fadeIn}
            className="font-serif text-[28px] md:text-[34px] font-light leading-[1.25] tracking-[-0.01em] text-foreground mb-4"
          >
            Product truth,<br />
            <span className="text-foreground/40">culturally converted.</span>
          </motion.h1>
          <motion.p
            {...fadeIn}
            transition={{ ...fadeIn.transition, delay: 0.06 }}
            className="text-[13px] text-foreground/45 leading-[1.7] max-w-[380px]"
          >
            Paste a product page URL. Extract brand signals and generate adapted taglines for the US and Japanese markets.
          </motion.p>
        </section>

        {/* Input */}
        <section className="pb-16">
          <form onSubmit={handleAnalyze} className="max-w-[480px]">
            <div className="flex items-center border-b border-foreground/10 focus-within:border-foreground/25 transition-colors">
              <Input
                type="url"
                placeholder="https://..."
                className="border-0 focus-visible:ring-0 shadow-none rounded-none h-10 text-[14px] px-0 placeholder:text-foreground/20"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                required
                data-testid="input-url"
              />
              <Button
                type="submit"
                disabled={isAnalyzing || !url}
                variant="ghost"
                className="h-10 px-3 rounded-none text-[12px] font-medium text-foreground/40 hover:text-foreground/70 transition-colors"
                data-testid="button-analyze"
              >
                {isAnalyzing ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <>
                    Analyze
                    <ArrowRight className="ml-1 h-3 w-3" />
                  </>
                )}
              </Button>
            </div>
          </form>
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="mt-3 flex items-center gap-2 text-destructive text-[12px]"
                data-testid="text-error"
              >
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{error}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Results */}
        <AnimatePresence>
          {results && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="pb-24"
              data-testid="section-results"
            >
              {/* ── Brand Narrative ── */}
              <motion.div {...fadeIn} className="border-t border-foreground/[0.06] pt-8 pb-10">
                <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-foreground/30 mb-3">Brand Narrative</p>
                <p className="text-[14px] leading-[1.75] text-foreground/65 max-w-[640px]" data-testid="text-brand-narrative">{results.brandNarrative}</p>
              </motion.div>

              {/* ── Consumer Insight: Voice + Truth ── */}
              <motion.div {...fadeIn} transition={{ ...fadeIn.transition, delay: 0.05 }} className="border-t border-foreground/[0.06] pt-8 pb-10">
                <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-foreground/30 mb-6">Consumer Insight</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  {/* Customer Voice */}
                  {results.reviewSnippets.length > 0 && (
                    <div>
                      <p className="text-[11px] text-foreground/35 mb-4">Customer Voice</p>
                      <div className="space-y-4">
                        {results.reviewSnippets.map((snippet, i) => (
                          <div key={i} className="pl-3 border-l-[2px] border-foreground/[0.08]" data-testid={`text-review-${i}`}>
                            <p className="text-[13px] leading-[1.7] text-foreground/50 italic">"{snippet}"</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Consumer Truth */}
                  <div>
                    <p className="text-[11px] text-foreground/35 mb-4">Validated Truth</p>
                    <div className="space-y-3">
                      {results.consumerTruths.map((t, i) => (
                        <div key={i} className="flex gap-2.5" data-testid={`text-consumer-truth-${i}`}>
                          <span className="text-[10px] font-mono text-foreground/15 mt-[2px] shrink-0">{String(i + 1).padStart(2, "0")}</span>
                          <p className="text-[13px] leading-[1.7] text-foreground/55">{t}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* ── Taglines Table (2-column: US | JP) ── */}
              <motion.div
                {...fadeIn}
                transition={{ ...fadeIn.transition, delay: 0.1 }}
                className="border-t border-foreground/[0.06]"
              >
                {/* Table Header */}
                <div className="grid grid-cols-[1fr_1fr] border-b border-foreground/[0.06]">
                  <div className="py-4 pr-6">
                    <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-foreground/30">United States</p>
                    <p className="text-[10px] text-foreground/20 mt-0.5">Direct · Confident · Concise</p>
                  </div>
                  <div className="py-4 pl-6 border-l border-foreground/[0.06]">
                    <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-foreground/30">Japan</p>
                    <p className="text-[10px] text-foreground/20 mt-0.5">Subtle · Emotional · Figurative</p>
                  </div>
                </div>

                {/* Tagline Rows */}
                {[0, 1, 2].map((idx) => (
                  <div key={idx} className="grid grid-cols-[1fr_1fr] border-b border-foreground/[0.06]">
                    <div className="py-5 pr-6 flex items-baseline gap-2.5" data-testid={`text-us-tagline-${idx}`}>
                      <span className="text-[10px] font-mono text-foreground/15 shrink-0">{String(idx + 1).padStart(2, "0")}</span>
                      <p className="text-[15px] font-medium tracking-[-0.01em] text-foreground/80 leading-snug">{results.usTaglines[idx]}</p>
                    </div>
                    <div className="py-5 pl-6 border-l border-foreground/[0.06] flex items-baseline gap-2.5" data-testid={`text-jp-tagline-${idx}`}>
                      <span className="text-[10px] font-mono text-foreground/15 shrink-0">{String(idx + 1).padStart(2, "0")}</span>
                      <p className="text-[13px] text-foreground/70 leading-snug">{results.japanTaglines[idx]}</p>
                    </div>
                  </div>
                ))}
              </motion.div>

              {/* ── Cultural Lens ── */}
              <motion.div
                {...fadeIn}
                transition={{ ...fadeIn.transition, delay: 0.15 }}
                className="border-t border-foreground/[0.06] pt-8 pb-12"
              >
                <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-foreground/30 mb-6">Cultural Lens</p>
                <div className="grid grid-cols-[1fr_1fr]">
                  {/* US Bars */}
                  <div className="pr-6 space-y-3">
                    {US_BARS.map((b) => (
                      <div key={b.label} className="flex items-center justify-between">
                        <span className="text-[11px] text-foreground/35 w-[80px]">{b.label}</span>
                        <MiniBar val={b.val} />
                      </div>
                    ))}
                  </div>
                  {/* JP Bars */}
                  <div className="pl-6 border-l border-foreground/[0.06] space-y-3">
                    {JP_BARS.map((b) => (
                      <div key={b.label} className="flex items-center justify-between">
                        <span className="text-[11px] text-foreground/35 w-[80px]">{b.label}</span>
                        <MiniBar val={b.val} />
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* ── Explanation ── */}
              <motion.div
                {...fadeIn}
                transition={{ ...fadeIn.transition, delay: 0.2 }}
                className="border-t border-foreground/[0.06] pt-8"
              >
                <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-foreground/30 mb-3">Why This Changed</p>
                <p className="text-[13px] leading-[1.8] text-foreground/50 max-w-[640px]" data-testid="text-explanation">
                  {results.explanation}
                </p>
              </motion.div>

            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
